//
//  ContentView.swift
//  DonutGraph_SwiftUI
//
//  Created by Pallavi Dash on 19/02/20.
//  Copyright © 2020 Pallavi Dash. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    @State var firstGraphDisplay = false
    @State var secGraphDisplay = false
    @State var firstEndAngle: String = "0.0"
    @State var secondEndAngle: String = "0.0"
    
    @State var temp1EndAngle: String = ""
    @State var temp2EndAngle: String = ""
    
    @ObservedObject var chartModel = ChartModel()
    
    var body: some View {

        VStack {
            
            //
            Text("Donut Graph")
                .font(.largeTitle)
                .fontWeight(.semibold)
            .padding(.top, 30)
            Divider()
            .padding(.bottom, 30)
            Spacer()
            
            HStack {
                Text("First End Angle:")
                TextField("Double value", text: $firstEndAngle)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .frame(width: 100, height: 20)
            }
            .padding(.bottom, 30)
            .padding(.trailing, 100)
            HStack {
                Text("Second End Angle:")
                TextField("", text: $secondEndAngle)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .frame(width: 100, height: 20)
            }
            .padding(.top, 20)
            .padding(.bottom, 60)
            .padding(.trailing, 100)
            
            Button(action: {
                self.temp1EndAngle = self.firstEndAngle
                self.temp2EndAngle = self.secondEndAngle
            }) {
                Image(systemName: "heart.fill")
                    .foregroundColor(.white)
            }
            .buttonStyle(DarkButtonStyle())
            .padding(.bottom, 20)
            
            ZStack {
                
                Circle()
                    .trim(from: 0, to: 1)
                    .stroke(Color.blue, lineWidth: 20)
                    .frame(width: chartModel.dynamicWidth(width: 300), height: chartModel.dynamicHeight(height: 300))
                    .opacity(0.2)
                    .padding(.bottom, 200)
                Circle()
                    .trim(from: firstGraphDisplay ? chartModel.calculateEndAngle(temp1EndAngle) : 1, to: 1)
                    .stroke(Color.blue, lineWidth: 20)
                    .frame(width: chartModel.dynamicWidth(width: 300), height: chartModel.dynamicHeight(height: 300))
                    .rotationEffect(.degrees(360.0), anchor: .center)
                    .animation(.easeInOut(duration: 0.8))
                    .padding(.bottom, 200)
                    .onAppear() {
                        self.firstGraphDisplay.toggle()
                }
                
                
                Circle()
                    .trim(from: 0, to: 1)
                    .stroke(Color.green, lineWidth: 20)
                    .frame(width: chartModel.dynamicWidth(width: 260), height: chartModel.dynamicHeight(height: 260))
                    .opacity(0.2)
                    .padding(.bottom, 200)
                
                Circle()
                    .trim(from: secGraphDisplay ? chartModel.calculateEndAngle(temp2EndAngle) : 1, to: 1)
                    .stroke(Color.green, lineWidth: 20)
                    .frame(width: chartModel.dynamicWidth(width: 260), height: chartModel.dynamicHeight(height: 260))
                    .rotationEffect(.degrees(360.0), anchor: .center)
                    .animation(.easeInOut(duration: 0.8))
                    .padding(.bottom, 200)
                    .onAppear() {
                        self.secGraphDisplay.toggle()
                }
            }
        }
    }
}

struct DarkButtonStyle: ButtonStyle {
    func makeBody(configuration: Self.Configuration) -> some View {
        configuration.label
            .padding(30)
            .contentShape(Circle())
            .background(
                DarkBackground(isHighlighted: configuration.isPressed, shape: Circle())
            )
            .animation(nil)
    }
}


struct DarkBackground<S: Shape>: View {
    var isHighlighted: Bool
    var shape: S

    var body: some View {
        ZStack {
            if isHighlighted {
                shape
                    .fill(LinearGradient(Color.darkEnd, Color.darkStart))
                    .overlay(shape.stroke(LinearGradient(Color.darkStart, Color.darkEnd), lineWidth: 4))
                    .shadow(color: Color.darkStart, radius: 10, x: 5, y: 5)
                    .shadow(color: Color.darkEnd, radius: 10, x: -5, y: -5)
            } else {
                shape
                    .fill(LinearGradient(Color.darkStart, Color.darkEnd))
                    .overlay(shape.stroke(Color.darkEnd, lineWidth: 4))
                    .shadow(color: Color.darkStart, radius: 10, x: -10, y: -10)
                    .shadow(color: Color.darkEnd, radius: 10, x: 10, y: 10)
            }
        }
    }
}

public class ChartModel: ObservableObject {
        
     func calculateEndAngle( _ percentageAsString: String) -> CGFloat {
        let percentageAsDouble = Double(percentageAsString) ?? 0.0
           let endAngle:CGFloat = CGFloat(percentageAsDouble/360)
         return endAngle
       }
    
    func dynamicHeight(height: CGFloat) -> CGFloat {
        return height
    }
    
    func dynamicWidth(width: CGFloat) -> CGFloat {
           return width
       }
}


extension Color {
    static let offWhite = Color(red: 225 / 255, green: 225 / 255, blue: 235 / 255)

    static let darkStart = Color(red: 50 / 255, green: 60 / 255, blue: 65 / 255)
    static let darkEnd = Color(red: 25 / 255, green: 25 / 255, blue: 30 / 255)

    static let lightStart = Color(red: 60 / 255, green: 160 / 255, blue: 240 / 255)
    static let lightEnd = Color(red: 30 / 255, green: 80 / 255, blue: 120 / 255)
}

extension LinearGradient {
    init(_ colors: Color...) {
        self.init(gradient: Gradient(colors: colors), startPoint: .topLeading, endPoint: .bottomTrailing)
    }
}
